# main.py - исправленный импорт
"""
Основной модуль FastAPI приложения EventList
"""
from fastapi import HTTPException, status
from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from datetime import datetime

from database import get_db, User, Group, Event, init_database

# ИСПРАВЛЕННЫЙ ИМПОРТ
from auth import router as auth_router  # Теперь это импорт из корневого auth.py
from api.users import router as users_router
from api.groups import router as groups_router
from api.events import router as events_router
from api.moderation import router as moderation_router

# Инициализация базы данных при старте
init_database()

app = FastAPI(
    title="EventList API",
    description="API для управления группами и событиями с аутентификацией по коду и модерацией",
    version="4.0.0"
)

# Подключаем роутеры напрямую
app.include_router(auth_router)
app.include_router(users_router)
app.include_router(groups_router)
app.include_router(events_router)
app.include_router(moderation_router)

@app.get("/")
async def root():
    """Корневой эндпоинт"""
    return {
        "message": "EventList API работает!",
        "version": "4.0.0",
        "docs": "/docs",
        "status": "active",
        "features": ["auth", "groups", "events", "moderation", "reports"]
    }


@app.get("/health")
async def health_check(db: Session = Depends(get_db)):
    """Проверка здоровья приложения и базы данных"""
    try:
        # Проверяем подключение к базе данных
        db.execute("SELECT 1")
        users_count = db.query(User).count()
        groups_count = db.query(Group).count()
        pending_groups = db.query(Group).filter(Group.status == 'pending').count()
        pending_events = db.query(Event).filter(Event.status == 'pending').count()

        return {
            "status": "healthy",
            "database": "connected",
            "users_count": users_count,
            "groups_count": groups_count,
            "pending_moderation": {
                "groups": pending_groups,
                "events": pending_events
            },
            "timestamp": datetime.now()
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Service unhealthy: {str(e)}"
        )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000, reload=True)